# Hình ảnh AI tham khảo

Đây là hình minh họa tạo bằng AI. File không đại diện cho người thật và không phải bằng chứng về hiệu suất quảng cáo.

- Có thể dùng để tham khảo bố cục và cách diễn đạt ý tưởng bằng hình ảnh.
- Kiểm tra lại quyền sử dụng, logo, chữ và thông tin thương hiệu trước khi đăng công khai.

