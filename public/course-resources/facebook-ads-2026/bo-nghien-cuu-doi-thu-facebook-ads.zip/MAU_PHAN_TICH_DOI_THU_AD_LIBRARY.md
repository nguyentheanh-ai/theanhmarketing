# Mẫu Phân Tích Đối Thủ Từ Meta Ad Library

## 1. Thông Tin Đầu Vào

| Mục | Nội dung |
|---|---|
| Ngành hàng/sản phẩm |  |
| Fanpage/link đối thủ |  |
| Quốc gia | Việt Nam |
| Trạng thái ads | Active |
| Ngày phân tích |  |
| Người/Agent thực hiện | Agent - Business Assistant |
| File research memory |  |

## 2. Link Search Đã Dùng

| Nhóm | Query/Page | Link |
|---|---|---|
| Ngành hàng |  |  |
| Nỗi đau |  |  |
| Giải pháp |  |  |
| Offer |  |  |
| Fanpage |  |  |

## 3. Keyword Relevance Log - Tối Thiểu 20 Key

| # | Keyword | Nhóm keyword | Link Ad Library | Số ads thấy được | Độ đúng ngành | Lý do giữ/loại | Dùng phân tích? | Key thay thế nếu loại |
|---:|---|---|---|---:|---|---|---|---|
| 1 |  | Sản phẩm |  |  | Đúng ngành/Gần ngành/Sai ngành/Không đủ dữ liệu |  | Có/Không |  |
| 2 |  | Nỗi đau |  |  |  |  |  |  |
| 3 |  | Giải pháp |  |  |  |  |  |  |
| 4 |  | Offer |  |  |  |  |  |  |
| 5 |  | Đối tượng |  |  |  |  |  |  |
| 6 |  | Đối thủ/thay thế |  |  |  |  |  |  |
| 7 |  | Phễu/CTA |  |  |  |  |  |  |
| 8 |  |  |  |  |  |  |  |  |
| 9 |  |  |  |  |  |  |  |  |
| 10 |  |  |  |  |  |  |  |  |
| 11 |  |  |  |  |  |  |  |  |
| 12 |  |  |  |  |  |  |  |  |
| 13 |  |  |  |  |  |  |  |  |
| 14 |  |  |  |  |  |  |  |  |
| 15 |  |  |  |  |  |  |  |  |
| 16 |  |  |  |  |  |  |  |  |
| 17 |  |  |  |  |  |  |  |  |
| 18 |  |  |  |  |  |  |  |  |
| 19 |  |  |  |  |  |  |  |  |
| 20 |  |  |  |  |  |  |  |  |

## 4. Kiểm Chính Sách Theo Fanpage/Ngành

| Mục | Nội dung |
|---|---|
| Ngành có nhạy cảm/hạn chế không? |  |
| Nguồn chính sách đã kiểm | Meta Advertising Standards / Meta Business Help |
| Rủi ro thuộc tính cá nhân |  |
| Rủi ro cam kết kết quả |  |
| Rủi ro claim tài chính/thu nhập/sức khỏe/làm đẹp |  |
| Rủi ro landing page/CTA |  |
| Cách viết/creative an toàn hơn |  |
| Mức chắc chắn | Chắc chắn / Suy luận / Cần kiểm tra lại |

## 5. Tổng Quan Số Lượng Và Chiến Lược Chạy

| Mục | Nhận định |
|---|---|
| Tổng số quảng cáo quan sát được |  |
| Số quảng cáo active |  |
| Số quảng cáo inactive nếu có |  |
| Số page/đối thủ nổi bật |  |
| Chiến lược chạy đang thấy | Test nhiều angle / scale một offer / remarketing / trust-proof / launch offer mới |
| Mẫu chạy lâu đáng chú ý |  |
| Mẫu mới bắt đầu test |  |

## 6. Competitor Map - Từ Keyword Sang Đối Thủ

| Đối thủ/page | Facebook page URL | Page ID | Ad Library page URL | Trạng thái link | Nguồn keyword | Loại đối thủ | Sản phẩm/offer chính | Số ads thấy được | Ngày chạy sớm nhất | Ngày chạy mới nhất | Angle chính | CTA chính | Vai trò phễu | Rủi ro chính sách | Giữ phân tích? | Lý do |
|---|---|---|---|---|---|---|---|---:|---|---|---|---|---|---|---|---|
|  |  |  |  | Chắc chắn/Fallback/Chưa lấy được |  | Trực tiếp/Gián tiếp/Nhiễu |  |  |  |  |  |  |  |  | Có/Không |  |

## 7. Phân Tích Từng Đối Thủ

### Đối thủ 1

| Mục | Phân tích |
|---|---|
| Page/brand |  |
| Facebook page URL |  |
| Page ID / Ad Library page URL |  |
| Họ đang bán gì |  |
| Tệp khách họ nhắm tới |  |
| Offer/giá/bonus nếu thấy |  |
| Hook/angle lặp lại |  |
| CTA/destination |  |
| Thời gian chạy đáng chú ý |  |
| Chiến lược suy luận |  |
| Điểm mạnh |  |
| Điểm yếu/khoảng trống |  |
| Rủi ro chính sách |  |
| Bài học cho khách |  |

## 8. Evidence Từng Quảng Cáo

| Page | Ad Library ID | Trạng thái | Ngày bắt đầu | Số ngày chạy | Format | Hook | Offer/sản phẩm/book | Proof | CTA | Đích đến | Mục tiêu phễu | Độ chắc chắn objective | Ghi chú chiến lược |
|---|---|---|---|---:|---|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |  |  |  |  | Suy luận/Chắc chắn/Không rõ |  |

## 9. Dữ Liệu Quan Sát Được

| Page | Format | Hook | Offer | CTA | Landing/Messenger | Ghi chú |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

## 10. Pattern Chính

| Pattern | Dấu hiệu | Ý nghĩa |
|---|---|---|
| Thông điệp |  |  |
| Creative |  |  |
| Offer |  |  |
| CTA |  |  |
| Proof/RTB |  |  |
| Thời gian chạy |  |  |
| Mục tiêu phễu |  |  |

## 11. Phân Tích CTA Và Mục Tiêu Phễu

| CTA/Đích đến | Mục tiêu phễu suy luận | Độ chắc chắn | Ý nghĩa |
|---|---|---|---|
|  |  |  |  |

## 12. Khoảng Trống Thị Trường

| Khoảng trống | Bằng chứng từ ads đang thấy | Cơ hội cho khách |
|---|---|---|
|  |  |  |

## 13. Gợi Ý Quảng Cáo Có Thể Test

| Ý tưởng | Tệp phù hợp | Hook | Offer/CTA | Format | Vì sao nên test |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## 14. Rủi Ro Và Lưu Ý Chính Sách

| Rủi ro | Cách viết an toàn hơn |
|---|---|
|  |  |

## 15. Handoff Cho Agent Khác

| Agent nhận | Việc cần làm | Đầu vào cần dùng |
|---|---|---|
| Agent - Marketing |  |  |
| Agent - Ads Setup |  |  |
